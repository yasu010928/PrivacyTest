#!/bin/bash

readonly ROOT=$(cd $(dirname ${BASH_SOURCE:-$0})/..; pwd)

# 使用にあたって理由が求められるAPI
# ref. https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api?language=objc
readonly REQUIRED_REASON_APIS=(
    # File timestamp APIs
    NSFileCreationDate
    creationDate
    NSFileModificationDate
    modificationDate
    fileModificationDate
    NSURLContentModificationDateKey
    contentModificationDateKey
    NSURLCreationDateKey
    creationDateKey
    getattrlist
    getattrlistbulk
    fgetattrlist
    stat
    fstat
    fstatat
    lstat
    getattrlistat
    # System boot time APIs
    systemUptime
    mach_absolute_time
    # Disk space APIs
    NSURLVolumeAvailableCapacityKey
    volumeAvailableCapacityKey
    NSURLVolumeAvailableCapacityForImportantUsageKey
    volumeAvailableCapacityForImportantUsageKey
    NSURLVolumeAvailableCapacityForOpportunisticUsageKey
    volumeAvailableCapacityForOpportunisticUsageKey
    NSURLVolumeTotalCapacityKey
    volumeTotalCapacityKey
    NSFileSystemFreeSize
    systemFreeSize
    NSFileSystemSize
    systemSize
    statfs
    statvfs
    fstatfs
    fstatvfs
    getattrlist
    fgetattrlist
    getattrlistat
    # Active keyboard APIs
    activeInputModes
    # User defaults APIs
    NSUserDefaults
    UserDefaults
)

# echo "${REQUIRED_REASON_APIS[@]}"
# exit

for api_name in "${REQUIRED_REASON_APIS[@]}"; do
    echo "Search $api_name" >&2
    grep -E "$api_name\W" -r /Users/y_takahashi/Desktop/dev/Privacy_API/eza_ios

    # 目視検査用。緩く広範にマッチさせようとする。
    #grep "$api_name" -r $ROOT/src
done
