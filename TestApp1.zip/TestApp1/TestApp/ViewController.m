//
//  ViewController.m
//  TestApp
//
//  Created by y_takahashi on 2024/04/05.
//

#import "ViewController.h"
#import <mach/mach_time.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (IBAction)buttonPush:(id)sender {

        NSString *appFilePath;
    
        //ホームディレクトリパスを取得
        appFilePath = NSHomeDirectory();
        //ディレクトリパスにappファイル名を追加。
        [appFilePath stringByAppendingString:@"TestApp.app"];
        
        //cでファイル情報をNSDictionaryにつめる。
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSError *err = nil;
        NSDictionary *fileInfoDict;
        
        fileInfoDict = [fileManager attributesOfItemAtPath:appFilePath error:&err];
        
        //NSDictionaryからappファイル作成日時を取得
        NSDate *fileInstallDate = [fileInfoDict objectForKey:NSFileCreationDate];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateStyle:NSDateFormatterMediumStyle];
        [formatter setTimeStyle:NSDateFormatterMediumStyle];
        
        //ラベルにアプリのインストール日時を表示
        self.labelText.text = [formatter stringFromDate:fileInstallDate];
    
        //システム起動時間の計測｀
        uint64_t start, elapsed;
        start = mach_absolute_time();
        // do something.
        elapsed = mach_absolute_time() - start;

        self.labelText2.text =  [NSString stringWithFormat:@"%llu", elapsed];
        
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];  // 取得
        NSMutableDictionary *defaults = [NSMutableDictionary dictionary];
        [defaults setObject:@"99" forKey:@"KEY_I"];
        [defaults setObject:@"99.99" forKey:@"KEY_F"];
        [defaults setObject:@"88.88" forKey:@"KEY_D"];
        [defaults setObject:@"YES" forKey:@"KEY_B"];
        [defaults setObject:@"hoge" forKey:@"KEY_S"];
        //registerDefaultsで登録
        [ud registerDefaults:defaults];
            
}
@end
