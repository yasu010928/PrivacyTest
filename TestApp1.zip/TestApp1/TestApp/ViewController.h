//
//  ViewController.h
//  TestApp
//
//  Created by y_takahashi on 2024/04/05.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *labelText;
- (IBAction)buttonPush:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *labelText2;

@end

