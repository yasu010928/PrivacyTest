//
//  SceneDelegate.h
//  TestApp
//
//  Created by y_takahashi on 2024/04/05.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

