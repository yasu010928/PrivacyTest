//
//  AppDelegate.h
//  TestApp
//
//  Created by y_takahashi on 2024/04/05.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <AppsFlyerLib/AppsFlyerLib.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,AppsFlyerLibDelegate>

@property (readonly, strong) NSPersistentContainer *persistentContainer;

- (void)saveContext;


@end

